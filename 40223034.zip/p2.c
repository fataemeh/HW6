#include<stdio.h>
#include<math.h>
int solver(float , float, float , float * , float *);
int main()
{
    float a, b , c , x , y ,*root1=&x ,*root2=&y;
    printf("enter 3 numbers");
    scanf("%f%f%f", &a , &b , &c); //ax^2+bx+c
    if(a==0 && b==0)
    printf("try again");

    else{
    solver(a,b,c,root1,root2);
    if(solver(a,b,c,root1,root2)==0)
    printf("the eqation has not root");

    else if(*root1==*root2)
    printf("the root is %2.2f and the number is 1",*root1);

    else
    printf("the roots are %2.2f %2.2f and the number is 2" , *root1 , *root2);
        }
}

 int solver(float a , float b , float c , float *root1 , float *root2)
{
float delta;
  delta=b*b-(4*a*c);
  if(delta<0)
  return 0;

  else{
 *root1=((-b)+sqrt(delta))/(2*a);
 *root2=((-b)-sqrt(delta))/(2*a);
      }
}